#include <iostream>
#include <vector>
#include <iomanip> 

using namespace std;

// Function to print a single disk with stars
void printDisk(int diskSize, int maxDiskSize) {
    int numStars = 2 * diskSize - 1;
    int numSpaces = maxDiskSize - diskSize;
    for (int i = 0; i < numSpaces; ++i) cout << " ";
    for (int i = 0; i < numStars; ++i) cout << "*";
    for (int i = 0; i < numSpaces; ++i) cout << " ";
}

// Towers state printing function
void printTowers(const vector<vector<int>>& towers) {
    int max_height = 0;
    int max_disk_size = 0;

    // Determine the maximum height of the towers and the maximum width of a disk
    for (const auto& tower : towers) {
        if (tower.size() > max_height) {
            max_height = tower.size();
        }
    }
    for (const auto& tower : towers) {
        for (const auto& disk : tower) {
            if (disk > max_disk_size) {
                max_disk_size = disk;
            }
        }
    }

    // Print the towers
    for (int i = max_height - 1; i >= 0; --i) {
        for (int j = 0; j < 3; ++j) {
            if (i < towers[j].size()) {
                int disk_size = towers[j][i];
                // Print the disk with proper width and alignment
                printDisk(disk_size, max_disk_size);
                cout << "\t";
            } else {
                // Print empty space for missing disks
                for (int k = 0; k < max_disk_size; ++k) cout << " ";
                cout << "|";
                for (int k = 0; k < max_disk_size; ++k) cout << " ";
                cout << "\t";
            }
        }
        cout << endl;
    }
    
    // Print the base line of the towers
    cout << string(3 * (2 * max_disk_size + 3), '-') << endl;
    cout << "A" << string(2 * max_disk_size + 1, ' ') << "   B   " << string(2 * max_disk_size + 1, ' ') << "C" << endl;
    cout << string(3 * (2 * max_disk_size + 3), '-') << endl;
}

// Move a disk from one tower to another
void moveDisk(vector<vector<int>>& towers, int disk, char from, char to) {
    int fromIndex = from - 'A';
    int toIndex = to - 'A';

    // Move the disk
    towers[toIndex].push_back(disk);
    towers[fromIndex].pop_back();

    // Print the state of the towers
    printTowers(towers);
}

// Recursive function to solve the Towers of Hanoi problem with graphical representation
void GraphicalHanoi(int n, char from, char aux, char to, vector<vector<int>>& towers) {
    if (n == 1) {
        moveDisk(towers, n, from, to);
        return;
    } else {
        GraphicalHanoi(n - 1, from, to, aux, towers);
        moveDisk(towers, n, from, to);
        GraphicalHanoi(n - 1, aux, from, to, towers);
    }
}

// Initialize and run the graphical representation of Towers of Hanoi
void runGraphicalHanoi() {
    int numberOfDisks;
    cout << "Number of disks: ";
    cin >> numberOfDisks;

    if (numberOfDisks < 1) {
        cout << "The number of disks must be greater than 1!" << endl;
        return;
    }

    vector<vector<int>> towers(3);
    for (int i = numberOfDisks; i >= 1; --i) {
        towers[0].push_back(i);
    }

    cout << "Initial State:" << endl;
    printTowers(towers);

    GraphicalHanoi(numberOfDisks, 'A', 'B', 'C', towers);
}
