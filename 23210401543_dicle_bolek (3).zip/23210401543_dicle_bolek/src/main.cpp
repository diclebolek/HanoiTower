#include "classic_hanoi.h"
#include "advanced_hanoi.h"
#include "iterative_hanoi.h"
#include "graphical_hanoi.h"
#include <iostream>
using namespace std;

void runClassicHanoi();
void runAdvancedHanoi();
void runIterativeHanoi();
void runGraphicalHanoi();

int main() {
    int choice;
    while (true) {
        cout << "\nTowers of Hanoi Problem\n";
        cout << "1. Classic Towers of Hanoi Problem (You can only enter 4 discs)\n";
        cout << "2. Advanced Towers of Hanoi Problem (5 or more disks)(With this option you can analyze the number of steps and time complexity.)\n";
        cout << "3. Iterative Solution for Towers of Hanoi\n";
        cout << "4. Graphical Representation\n";
        cout << "5. Exit\n";
        cout << "Your choice: ";

        cin >> choice;

        switch (choice) {
            case 1:
                runClassicHanoi();
                break;
            case 2:
                runAdvancedHanoi();
                break;
            case 3:
                runIterativeHanoi();
                break;
            case 4:
                runGraphicalHanoi();
                break;
            case 5:
                return 0;
            default:
                cout << "Invalid selection. Please try again.\n";
        }
    }
    return 0;

}
