#include <iostream>
#include <vector>
#include <iomanip> // For setw
#include <cmath>
using namespace std;

// Print the state of the towers
void printTowersAdvanced(const vector<vector<int>>& towers, int maxDiskSize) {
    int max_height = 0;

    // Find the maximum height of the towers
    for (const auto& tower : towers) {
        if (tower.size() > max_height) {
            max_height = tower.size();
        }
    }

    // Print each level of the towers
    for (int i = max_height - 1; i >= 0; --i) {
        for (int j = 0; j < 3; ++j) {
            if (i < towers[j].size()) {
                int disk = towers[j][i];
                int width = maxDiskSize;
                cout << setw(width) << right << disk << " ";
            } else {
                cout << setw(maxDiskSize) << "|" << " ";
            }
        }
        cout << endl;
    }

    // Print the base and rod labels
    cout << string(3 * (maxDiskSize + 1), '-') << endl;
    cout << setw(maxDiskSize) << "A" << setw(maxDiskSize + 1) << "B" << setw(maxDiskSize + 1) << "C" << endl;
    cout << string(3 * (maxDiskSize + 1), '-') << endl;
}

// Move a disk from one tower to another and print the towers
void moveDiskAdvanced(vector<vector<int>>& towers, int disk, char from, char to, int maxDiskSize) {
    int fromIndex = from - 'A';
    int toIndex = to - 'A';

    // Move the disk
    towers[toIndex].push_back(disk);
    towers[fromIndex].pop_back();

    // Print the state of the towers
    printTowersAdvanced(towers, maxDiskSize);
}

// Recursive function to solve the Towers of Hanoi problem with visual representation
void AdvancedHanoi(int n, char source, char auxiliary, char target, vector<vector<int>>& towers, int maxDiskSize) {
     if (n == 1) {
        cout << n << ". Move disk from " << source << " to " << target << "." << endl;
        moveDiskAdvanced(towers, n, source, target, maxDiskSize);
        return;
    } else {
        AdvancedHanoi(n - 1, source, target, auxiliary, towers, maxDiskSize);
        cout << n << ". Move disk from " << source << " to " << target << "." << endl;
        moveDiskAdvanced(towers, n, source, target, maxDiskSize);
        AdvancedHanoi(n - 1, auxiliary, source, target, towers, maxDiskSize);
    }
}

void runAdvancedHanoi() {
    int numberOfDisks;
    cout << "Number of Disks (5 and above): ";
    cin >> numberOfDisks;
    if (numberOfDisks < 5) {
        cout << "Invalid disk number. Please select 5 or more." << endl;
        return;
    }

    vector<vector<int>> towers(3);
    for (int i = numberOfDisks; i >= 1; --i) {
        towers[0].push_back(i);
    }

    cout << "Initial State:" << endl;
    printTowersAdvanced(towers, numberOfDisks);

    AdvancedHanoi(numberOfDisks, 'A', 'B', 'C', towers, numberOfDisks);

    // Analyze the number of steps and time complexity
    int numberOfSteps = pow(2, numberOfDisks) - 1;
    cout << "Number of Steps: " << numberOfSteps << endl;
    int timeComplexity= pow(2, numberOfDisks);
    cout << "Time Complexity: O(2^" << numberOfDisks << ")" << "=" << timeComplexity << endl;
}
