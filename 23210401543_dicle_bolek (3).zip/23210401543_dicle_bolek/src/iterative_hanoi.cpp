#include <iostream>
#include <stack>
#include <vector>
using namespace std;

struct Move {
    int disk;
    char from;
    char to;
    char aux;
};

void printTowers2(const vector<vector<int>>& towers) {
    int max_height = 0;
    for (const auto& tower : towers) {
        if (tower.size() > max_height) {
            max_height = tower.size();
        }
    }

    for (int i = max_height - 1; i >= 0; --i) {
        for (int j = 0; j < 3; ++j) {
            if (i < towers[j].size()) {
                cout << towers[j][i] << "\t";
            } else {
                cout << "|\t";
            }
        }
        cout << endl;
    }
    cout << "-----------------" << endl;
    cout << "A\tB\tC" << endl;
    cout << "-----------------" << endl;
}

void iterativeHanoi(int n) {
    vector<vector<int>> towers(3);
    for (int i = n; i >= 1; --i) {
        towers[0].push_back(i);
    }

    int totalMoves = (1 << n) - 1; // 2^n - 1 moves
    char from = 'A', to = 'C', aux = 'B';

    if (n % 2 == 0) {
        swap(to, aux);
    }

    stack<Move> moves;
    moves.push({n, from, to, aux});

    while (!moves.empty()) {
        Move move = moves.top();
        moves.pop();

        if (move.disk == 1) {
            // Move disk directly
            int fromIndex = move.from - 'A';
            int toIndex = move.to - 'A';
            int disk = towers[fromIndex].back();
            towers[fromIndex].pop_back();
            towers[toIndex].push_back(disk);
            printTowers2(towers);
        } else {
            // Push tasks for the smaller problem
            moves.push({move.disk - 1, move.aux, move.to, move.from});
            moves.push({1, move.from, move.to, move.aux});
            moves.push({move.disk - 1, move.from, move.aux, move.to});
        }
    }
}

void runIterativeHanoi() {
    int numberOfDisks;
    cout << "Number of Disks (3 and above): ";
    cin >> numberOfDisks;

    if (numberOfDisks < 3) {
        cout << "Invalid disk number. Please select 3 or more." << endl;
        return;
    }

    cout << "Initial State:" << endl;
    vector<vector<int>> towers(3);
    for (int i = numberOfDisks; i >= 1; --i) {
        towers[0].push_back(i);
    }
    printTowers2(towers);

    iterativeHanoi(numberOfDisks);
}