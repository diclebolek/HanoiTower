#include "classic_hanoi.h"
#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

// Function to print a single disk with stars
void printDisk1(int diskSize, int maxDiskSize) {
    int numStars = 2 * diskSize - 1;
    int numSpaces = maxDiskSize - diskSize;
    for (int i = 0; i < numSpaces; ++i) cout << " ";
    for (int i = 0; i < numStars; ++i) cout << "*";
    for (int i = 0; i < numSpaces; ++i) cout << " ";
}

// Towers state printing function
void printTowersClassic(const std::vector<std::vector<int>>& towers, int maxDiskSize) {
    int max_height = 0;

    // Find the maximum height of the towers
    for (const auto& tower : towers) {
        if (tower.size() > max_height) {
            max_height = tower.size();
        }
    }

    // Print each level of the towers
    for (int i = max_height - 1; i >= 0; --i) {
        for (int j = 0; j < 3; ++j) {
            if (i < towers[j].size()) {
                int disk = towers[j][i];
                int width = maxDiskSize; // Define the width for disks
                cout << setw(width) << left << disk << " ";
            } else {
                cout << setw(maxDiskSize) << "|" << " ";
            }
        }
        cout << endl;
    }

    // Print the base and rod labels
    cout << string(3 * (maxDiskSize + 1), '-') << endl;
    cout << setw(maxDiskSize) << "|A" << setw(maxDiskSize + 1) << " B" << setw(maxDiskSize + 1) << " C|" << endl;
    cout << string(3 * (maxDiskSize + 1), '-') << endl;
}

// Move a disk from one tower to another
void moveDisk1(vector<vector<int>>& towers, int disk, char from, char to, int maxDiskSize) {
    int fromIndex = from - 'A';
    int toIndex = to - 'A';

    // Move the disk
    towers[toIndex].push_back(disk);
    towers[fromIndex].pop_back();

    // Print the state of the towers
    printTowersClassic(towers, maxDiskSize);
}

// Recursive function to solve the Towers of Hanoi problem with graphical representation
void printStepsAndMoveDisks(int n, char from, char to, char aux, vector<vector<int>>& towers, int maxDiskSize) {
    if (n == 1) {
        cout << "Move disk 1 from " << from << " to " << to << "." << endl;
        moveDisk1(towers, 1, from, to, maxDiskSize);
        return;
    } else {
        printStepsAndMoveDisks(n - 1, from, aux, to, towers, maxDiskSize);
        cout << "Move disk " << n << " from " << from << " to " << to << "." << endl;
        moveDisk1(towers, n, from, to, maxDiskSize);
        printStepsAndMoveDisks(n - 1, aux, to, from, towers, maxDiskSize);
    }
}

void runClassicHanoi() {
    int diskCount;
    cout << "Number of Disks (4): ";
    cin >> diskCount;

    if (diskCount != 4) {
        cout << "Invalid disk number. Please select exactly 4 disks." << endl;
        return;
    }

    vector<vector<int>> towers(3);
    for (int i = diskCount; i >= 1; --i) {
        towers[0].push_back(i);
    }

    cout << "Initial State:" << endl;
    printTowersClassic(towers, diskCount);

    printStepsAndMoveDisks(diskCount, 'A', 'C', 'B', towers, diskCount);
}
