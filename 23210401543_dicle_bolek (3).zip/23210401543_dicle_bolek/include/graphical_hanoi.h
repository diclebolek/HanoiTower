#ifndef TOWERSOFHANOI_HPP
#define TOWERSOFHANOI_HPP

#include <vector>

void printTowers(const std::vector<std::vector<int>>& towers);
void moveDisk(std::vector<std::vector<int>>& towers, int disk, char from, char to);
void GraphicalHanoi(int n, char from, char aux, char to, std::vector<std::vector<int>>& towers);
void runGraphicalHanoi();

#endif // TOWERSOFHANOI_HPP

