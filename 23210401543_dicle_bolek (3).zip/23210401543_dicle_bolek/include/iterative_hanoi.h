#ifndef ITERATIVE_HANOI_H
#define ITERATIVE_HANOI_H

#include <vector>

struct Move {
    int disk;
    char from;
    char to;
    char aux;
};

// Function to print the current state of the towers
void printTowers2(const std::vector<std::vector<int>>& towers);

// Function to solve the Towers of Hanoi problem iteratively
void iterativeHanoi(int n);

// Function to run the iterative Towers of Hanoi solution
void runIterativeHanoi();

#endif // ITERATIVE_HANOI_H
