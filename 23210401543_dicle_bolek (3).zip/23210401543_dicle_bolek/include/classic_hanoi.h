#ifndef CLASSIC_HANOI_HPP
#define CLASSIC_HANOI_HPP

#include <vector>

// Function to print a single disk with stars
void printDisk1(int diskSize, int maxDiskSize);

// Towers state printing function
void printTowersClassic(const std::vector<std::vector<int>>& towers, int maxDiskSize);

// Move a disk from one tower to another
void moveDisk1(std::vector<std::vector<int>>& towers, int disk, char from, char to, int maxDiskSize);

// Recursive function to solve the Towers of Hanoi problem with graphical representation
void printStepsAndMoveDisks(int n, char from, char to, char aux, std::vector<std::vector<int>>& towers, int maxDiskSize);

// Function to run the classic Hanoi Tower problem
void runClassicHanoi();

#endif // CLASSIC_HANOI_HPP
