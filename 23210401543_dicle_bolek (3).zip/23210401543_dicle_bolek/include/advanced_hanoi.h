#ifndef ADVANCED_HANOI_HPP
#define ADVANCED_HANOI_HPP

#include <vector>

// Function to print the state of the towers
void printTowersAdvanced(const std::vector<std::vector<int>>& towers, int maxDiskSize);

// Function to move a disk from one tower to another and print the towers
void moveDiskAdvanced(std::vector<std::vector<int>>& towers, int disk, char from, char to, int maxDiskSize);

// Recursive function to solve the Towers of Hanoi problem with visual representation
void AdvancedHanoi(int n, char source, char auxiliary, char target, std::vector<std::vector<int>>& towers, int maxDiskSize);

// Function to initialize and run the graphical representation of Towers of Hanoi
void runAdvancedHanoi();

#endif // ADVANCED_HANOI_HPP

